//
//  FloatingActionButton.swift
//  Menu Button
//
//  Created by Admin on 28/03/1941 Saka.
//  Copyright © 1941 Devrim. All rights reserved.
//

import UIKit

class FloatingActionButton: UIButtonX {
    
    override func beginTracking(_ touch: UITouch, with event: UIEvent?) -> Bool {
        UIView.animate(withDuration: 0.3, animations: {
        if self.transform == .identity {
        self.transform = CGAffineTransform(rotationAngle: 45 * (.pi / 180))
        } else {
            self.transform = .identity
            }
        })
        return super.beginTracking(touch, with: event)
    }
   
    
}
