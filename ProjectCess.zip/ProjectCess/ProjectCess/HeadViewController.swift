//
//  HeadViewController.swift
//  ProjectCess
//
//  Created by Admin on 26/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class HeadViewController: UIViewController , UIGestureRecognizerDelegate{

    @IBOutlet weak var ayushView: UIView!
    @IBOutlet weak var ayushImageView: UIImageView!
    
    @IBAction func ayushBatiaFacebook(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://www.facebook.com/ayush.bhatia.5249")! , options:[:], completionHandler: nil)
    }

    @IBAction func ayushBhatiaInsta(_ sender: Any) {
         UIApplication.shared.open(URL(string: "http://instagram.com/a_ayush__")! , options:[:], completionHandler: nil)
    }

        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let swipeLeft =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleLeftSwipe));
        
        swipeLeft.direction = UISwipeGestureRecognizer.Direction.left
        swipeLeft.delegate = self;
        ayushView.addGestureRecognizer(swipeLeft)
        // Do any additional setup after loading the view.
    }
    
    @objc func handleLeftSwipe(){
            print("HelloWorldSwipe1")
        performSegue(withIdentifier: "MoveToKavish", sender: nil)
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
