//
//  LoggedInScreenViewController.swift
//  ProjectCess
//
//  Created by Admin on 07/07/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase
import GoogleSignIn
import Kingfisher
import Lottie

class LoggedInScreenViewController: UIViewController, UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    @IBOutlet weak var UserName: UILabel!
   //SignedInAnimation
   //SignedInViewOfLottiee
    
    
    @IBOutlet weak var SignedInAnimation: AnimationView!
    
    @IBOutlet weak var SignedInViewOfLottiee: UIView!
    
    
    
    
     @IBOutlet weak var pickImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        StartAnimation();
        
        DownloadDataFromCloud();
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: {
            self.disableSignedInAnimationViewOfLottiee();
        })
  
        // Do any additional setup after loading the view.
    }
    @IBAction func pickImageButton(_ sender: Any) {
        let myPickerController = UIImagePickerController()
        myPickerController.delegate = self
        myPickerController.allowsEditing = true
        myPickerController.sourceType = .photoLibrary
        
        
        self.present(myPickerController, animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        var selectedImageFromPicker: UIImage?
        if let editedImage = info[.editedImage] as? UIImage {
            selectedImageFromPicker = editedImage
        } else if let originalImage = info[.originalImage] as? UIImage {
            selectedImageFromPicker = originalImage
        }
        
        if let selectedImage = selectedImageFromPicker {
            pickImage.image = selectedImage
            ImageUploadFunc();
        }
        
        //        pickImage.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        let maskOfImage = UIImageView();
        maskOfImage.image = UIImage(named: "mask")
        pickImage.mask = maskOfImage;
        maskOfImage.frame = pickImage.bounds
        self.dismiss(animated: true, completion: nil)
        
    }
    
    
    func ImageUploadFunc(){
        
        let imageName = NSUUID().uuidString
        
        guard let uploadData = pickImage.image!.pngData() else { return };
        let storageRef = FIRStorage.storage().reference().child("ProfileImages").child(imageName);
        storageRef.put(uploadData , metadata: nil, completion:{(metaData,error) in
            if error != nil{
                print(error!)
                return
            }
            print(metaData!)
            let uid = FIRAuth.auth()?.currentUser?.uid
            print(uid!)
            
            let profileImageUrl = metaData?.downloadURL()?.absoluteString
            
            let value = ["ProfileImage": profileImageUrl]
            FIRDatabase.database().reference().child("users").child(uid!).updateChildValues(value)
        })
    }
    
    
    
//    func DownloadingNameFromCloud(){
//        let uid = FIRAuth.auth()?.currentUser?.uid
//        FIRDatabase.database().reference().child("users").child(uid!).observeSingleEvent(of: .value, with: {(snapshot) in
//
//            if let dictionary = snapshot.value as? [String:AnyObject]{
//                self.UserName.text = dictionary["username"] as? String
//
//            }
//
//            print(snapshot)
//        }, withCancel: nil)
//    }
    
    func DownloadDataFromCloud(){
        let uid = FIRAuth.auth()?.currentUser?.uid
         DispatchQueue.main.asyncAfter(deadline: .now() + 6.0, execute: { FIRDatabase.database().reference().child("users").child(uid!).observeSingleEvent(of: .value, with: {(snapshot) in
            
            if let dictionary = snapshot.value as? [String:AnyObject]{
                self.UserName.text = dictionary["username"] as? String
                
                let imageUrl = dictionary["ProfileImage"] as? String
                let url = URL(string: imageUrl ?? "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/ProfileImages%2F3FA51A88-8450-419C-BE36-C4344E48D82B?alt=media&token=a05741a2-c8ef-4431-934a-8350b3183924")
                
                ///WORKING ============================
                KingfisherManager.shared.retrieveImage(with: url! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
                    self.pickImage.image = image
                    let maskOfImage = UIImageView();
                    maskOfImage.image = UIImage(named: "mask")
                    self.pickImage.mask = maskOfImage;
                    maskOfImage.frame = self.pickImage.bounds
                }
            }
            
            print(snapshot)
        }, withCancel: nil)
    }
        )}
    
    
    @IBAction func logOutButton(_ sender: Any) {
        
        GIDSignIn.sharedInstance()?.signOut()
        
        
        let storyBoard = UIStoryboard(name: "Main" , bundle: nil)
        let nextController = storyBoard.instantiateViewController(withIdentifier: "SignInButtonScreen") as! AuthentificationViewController
        self.present(nextController, animated: true, completion: nil)
        
    }
    
    func StartAnimation(){
        SignedInAnimation.animation = Animation.named("912-dna-like-loader")
        SignedInAnimation.play()
        SignedInAnimation.loopMode = .loop
        SignedInAnimation.contentMode = .scaleAspectFit
    }
    
    func disableSignedInAnimationViewOfLottiee(){
       SignedInViewOfLottiee.isHidden = true

    }
    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
