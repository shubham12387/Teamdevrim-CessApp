//
//  DOpenPanelViewController.swift
//  ProjectCess
//
//  Created by Admin on 16/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class DOpenPanelViewController: UIViewController {
    
    @IBOutlet weak var ImageViewTechnicalPanel: NSLayoutConstraint!
    
  
    @IBAction func BACKBUTTON(_ sender: Any) {
        ImageViewTechnicalPanel.constant = 500
        UIView.animate(withDuration: 0.2, animations:{
            self.view.layoutIfNeeded()
        })
    }
    
     @IBOutlet weak var imagesOfHeads: UIImageView!
    
   ///////////////////////////////////////////////
   //////////////////////////////////       TECHNICAL TEAM

    @IBAction func bharatPicButtpn(_ sender: Any) {
            imagesOfHeads.image = UIImage(named: "BHARATNISCHALS")
        animationOfImagesOfHeads();
    }
    
    @IBAction func RumeetPicButton(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "RUMEETS")
        animationOfImagesOfHeads();
    }
 
    @IBAction func harmanPicButton(_ sender: Any) {
        
        imagesOfHeads.image = UIImage(named: "HARMANS")
        animationOfImagesOfHeads();
    }
    
    
/////////////////////////////////////////////////
////////////////////////////      DESIGN TEAM
 
    @IBAction func manjotSinghPicButton(_ sender: Any) {   imagesOfHeads.image = UIImage(named: "MANJOTS")
        animationOfImagesOfHeads();
    }
    
    @IBAction func akshitBhatiaPicButton(_ sender: Any) {   imagesOfHeads.image = UIImage(named: "AKSHITS")
        animationOfImagesOfHeads();
    }
    

    
//////////////////////////////////////////////////
    ////////////////////////////      PLACEMENTTEAM
    @IBAction func guntashPicButton(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "GuntashPic")
        animationOfImagesOfHeads();
    }
    @IBAction func madhavChopraPICBUTTON(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "MADHAVS")
        animationOfImagesOfHeads();
    }
    
    //////////////////////////////////////////////////
    ////////////////////////////      Fine Arts Team
    
    @IBAction func devanshiAggarwalPic(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "DEVANSHI")
        animationOfImagesOfHeads();
    }
    @IBAction func shrutiPicButton(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "SHRUTIS")
        animationOfImagesOfHeads();
    }
    
    
    
    //////////////////////////////////////////////////
    ////////////////////////////      Promotion Team
    @IBAction func riyaMittalPic(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "RIYAS")
        animationOfImagesOfHeads();

    }
    @IBAction func kritiRikhiPic(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "KRITIS")
        animationOfImagesOfHeads();
        
    }
    
    //////////////////////////////////////////////////
    ////////////////////////////      Public Realtion Team
    
    @IBAction func diyakshiPicButton(_ sender: Any) {  imagesOfHeads.image = UIImage(named: "DIVYAKSHI")
        animationOfImagesOfHeads();
    }
    
    @IBAction func gaganDeepSinghPic(_ sender: Any) {  imagesOfHeads.image = UIImage(named: "GAGANDEEPS")
        animationOfImagesOfHeads();
    }
    
    ///////////////////////////////////////////////
    //////////////////////////////////      Literary TEAM
    
    @IBAction func geetanjliPicButton(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "GEETANJALIS")
        animationOfImagesOfHeads();
    }
    
    @IBAction func ayushKaushikPicButton(_ sender: Any) {
        imagesOfHeads.image = UIImage(named: "DEVANSHI")
        animationOfImagesOfHeads();
    }
    
    func animationOfImagesOfHeads(){
        ImageViewTechnicalPanel.constant = 0;
        UIView.animate(withDuration: 0.3, animations:{
            self.view.layoutIfNeeded()
        })        
    }
    
//    
//    @IBAction func literaryBackButton(_ sender: Any) {
//         dismiss(animated: true, completion: nil)
//    }
//    
//    @IBAction func publicRelationTeam(_ sender: Any) {
//         dismiss(animated: true, completion: nil)
//    }
//    
//    @IBAction func designButton(_ sender: Any) {
//         dismiss(animated: true, completion: nil)
//    }
//    
//    @IBAction func technicalTeamButton(_ sender: Any) {
//         dismiss(anima2ted: true, completion: nil)
//    }
//    
//    @IBAction func placementButton(_ sender: Any) {
//         dismiss(animated: true, completion: nil)
//    }
//    
//    
//    @IBAction func fineArtButton(_ sender: Any) {
//         dismiss(animated: true, completion: nil)
//    }
//    
//    
//    @IBAction func protiomalButton(_ sender: Any) {
//         dismiss(animated: true, completion: nil)
//    }
//    
//    /////////////////// INSTA ID
    ////////////////////////
    @IBAction func gaganDeepSinghInstaId(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://www.instagram.com/gagan_312000/")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func divyakshiInstaId(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://instagram.com/divyakshi_99?igshid=pnlgmwb02upo")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func shrutiInstaId(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://instagram.com/shruti._.13199?igshid=nk1wxbri35a1")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func madhavChopraInstaId(_ sender: Any) {
         UIApplication.shared.open(URL(string: "http://instagram.com/madhavchopra01")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func majotSinghInstaId(_ sender: Any) {
         UIApplication.shared.open(URL(string: "http://instagram.com/manjots1607")! , options:[:], completionHandler: nil)
    }
    
 
    @IBAction func devanshiAggarwalInstaId(_ sender: Any) {
         UIApplication.shared.open(URL(string: "http://instagram.com/diva_d011")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func ayushKaushikInstaId(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://www.instagram.com/ayush_.kaushik/")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func geetanjliInstaId(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://www.instagram.com/bharatnischal/?hl=en")! , options:[:], completionHandler: nil)
    }
    
 
    
    @IBAction func bharatNischalInstaButton(_ sender: Any) {
          UIApplication.shared.open(URL(string: "https://www.instagram.com/bharatnischal/?hl=en")! , options:[:], completionHandler: nil)
    }
    
  
    @IBAction func rumeetInstaButton(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.instagram.com/rumeet._.singh/")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func harmandeepSinghInstaButton(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://www.instagram.com/harman._deep._singh/")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func akshitInstaButton(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://www.instagram.com/_.akshit._/?hl=en.")! , options:[:], completionHandler: nil)
    }
    @IBAction func guntashInstButton(_ sender: Any) {
           UIApplication.shared.open(URL(string: "https://www.instagram.com/guntash_03/?hl=en")! , options:[:], completionHandler: nil)
    }
    @IBAction func kritiRIkhiInsta(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://www.instagram.com/bliss_full6/")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func riyaMittalInsta(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://instagram.com/riyyuu__")! , options:[:], completionHandler: nil)
    }
    
    
    /////
    
    ///// FACEBOOK ID
    
    /////
    
    @IBAction func rumeetFacebookId(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/rumeet.singh.16")! , options:[:], completionHandler: nil)
    }
    @IBAction func harmanDeepFacebookId(_ sender: Any) {
     UIApplication.shared.open(URL(string: "https://www.facebook.com/harmandeepsinghhds")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func bharatNishal(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/profile.php?id=100017445368356")! , options:[:], completionHandler: nil)
    }
    @IBAction func shrutiFacebookButton(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://m.facebook.com/profile.php?id=100007633125707&ref=content_filter")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func devanshiAggarwal(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/harmandeepsinghhds")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func kritiFacebookButton(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/harmandeepsinghhds")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func riyaMittal(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/profile.php?id=100026094632610")! , options:[:], completionHandler: nil)
    }
    @IBAction func madhavChopra(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/madhav.chopra.507")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func guntash(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/guntash.kapoor")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func akshitBhatia(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/harmandeepsinghhds")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func manjotSingh(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/msinghpruthi")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func divyakshi(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/harmandeepsinghhds")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func gagandeepSingh(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/profile.php?id=100006860351128")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func geetanjali(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/harmandeepsinghhds")! , options:[:], completionHandler: nil)
    }
    @IBAction func ayushKaushik(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://m.facebook.com/ayush.kaushik.376?ref=bookmarks")! , options:[:], completionHandler: nil)
    }
    
    
    
    
    
    /////
   ///// TWITTER ID
   /////
    
    
    @IBAction func rumeetSinghTwitterId(_ sender: Any) {
          UIApplication.shared.open(URL(string: "https://twitter.com/rumeet_bti?s=08")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func harmanDeepSinghTwitter(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://twitter.com/hdsingh_13?s=17")! , options:[:], completionHandler: nil)
    }
    
  //////////////////////////////////////
    
    
   ////////////// GITHUB
    @IBAction func devanshiGithub(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://github.com/devanshi011")! , options:[:], completionHandler: nil)
    }
    @IBAction func bharatNischalGithub(_ sender: Any) {
         UIApplication.shared.open(URL(string: "https://github.com/BharatNischal")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func kritiRikhiGithub(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://github.com/kritirikhi")! , options:[:], completionHandler: nil)
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
