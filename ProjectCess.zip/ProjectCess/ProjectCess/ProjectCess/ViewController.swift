//
//  ViewController.swift
//  ProjectCess
//
//  Created by Admin on 12/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit
import Google
import GoogleSignIn
import FirebaseAuth
import Kingfisher
import FirebaseRemoteConfig

class ViewController: UIViewController , UIGestureRecognizerDelegate{
    
    
    
    /////PopUpParameters
    
    
  
    //var PopUpHeadingLabelText:String = "Seminar By SKP"
    
  
    @IBOutlet weak var BlurredImagesPanelConstrain: NSLayoutConstraint!
    @IBOutlet weak var BlurredViewandImagesWhenPopUpShows: UIVisualEffectView!
   
    
    ////////BUTTONS OF POPUPS
    @IBAction func closeButtonOfPopUp(_ sender: Any) {
        
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
             self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
    
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.PopUpViewFirstImage.constant = 500
            self.view.layoutIfNeeded()
            
           
        }, completion: nil)
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
        self.PopUpViewForFirstImage.isHidden = true;
    }
    @IBAction func closeSecondPopUpView(_ sender: Any) {
        
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.PopUpSecondViewConstrain.constant = 500
            self.view.layoutIfNeeded()
            
            
        }, completion: nil)
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
        self.PopUpSecondView.isHidden = true;
    }
    
    @IBAction func closeThirdPopUpView(_ sender: Any) {
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.PopUpThirdViewConstrain.constant = 500
            self.view.layoutIfNeeded()
            
            
        }, completion: nil)
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
        self.PopUpThirdView.isHidden = true;
    }
    
    @IBAction func closeFourthPopUpView(_ sender: Any) {
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.PopUpFourthViewConstrain.constant = 500
            self.view.layoutIfNeeded()
            
            
        }, completion: nil)
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
        self.PopUpFourthView.isHidden = true;
    }
    
    //////////////
    
    
    
    /////All 4 Pop Ups
    ////1 PopUp
    @IBOutlet weak var PopUpViewFirstImage: NSLayoutConstraint!
    @IBOutlet weak var PopUpViewForFirstImage: UIView!
    @IBOutlet weak var PopUpMainImage: UIImageView!
    @IBOutlet weak var PopUpHeadingLabel: UILabel!
    @IBOutlet weak var PopUpBodyText: UITextView!
    @IBOutlet weak var PopUpRedBarText: UITextView!
    @IBOutlet weak var CustomViewWithinPopUpView: CustomUIView!
    @IBOutlet weak var PopUpFirstVenue: CustomTextField!
    @IBOutlet weak var PopUpFirstTiming: CustomTextField!
    
    ////2 PopUp
    @IBOutlet weak var PopUpSecondView: UIView!
    @IBOutlet weak var PopUpSecondViewConstrain: NSLayoutConstraint!
    @IBOutlet weak var PopUpSecondHeadLabel: UILabel!
    @IBOutlet weak var PopUpSecondBodyText: UITextView!
    @IBOutlet weak var PopUpSecondViewRedLabelText: UITextView!
    @IBOutlet weak var PopUpSecondViewCustomView: CustomUIView!
    @IBOutlet weak var PopUpSecondVenue: CustomTextField!
    @IBOutlet weak var PopUpSecondTiming: CustomTextField!
    
    //// 3 PopUp
    @IBOutlet weak var PopUpThirdView: UIView!
    @IBOutlet weak var PopUpThirdViewConstrain: NSLayoutConstraint!
    @IBOutlet weak var PopUpThirdHeadLabel: UILabel!
    @IBOutlet weak var PopUpThirdBodyText: UITextView!
    @IBOutlet weak var PopUpThirdRedLabelText: UITextView!
    @IBOutlet weak var PopUpThirdViewCustomView: CustomUIView!
    @IBOutlet weak var PopUpThirdVenue: CustomTextField!
    @IBOutlet weak var PopUpThirdTiming: CustomTextField!
    
    ///// 4 PopUp
    @IBOutlet weak var PopUpFourthView: UIView!
    @IBOutlet weak var PopUpFourthViewConstrain: NSLayoutConstraint!
    @IBOutlet weak var PopUpFourthHeadLabel: UILabel!
    @IBOutlet weak var PopUpFourthBodyText: UITextView!
    @IBOutlet weak var PopUpFourthRedLabelText: UITextView!
    @IBOutlet weak var PopUpFourthViewCustomView: CustomUIView!
    @IBOutlet weak var PopUpFourthVenue: CustomTextField!
    @IBOutlet weak var PopUpFourthTiming: CustomTextField!
    
    
    
    
    ////////PopUpParametersCloseUp
    
    
    
    
    @IBOutlet weak var menuView: UIViewX!
    @IBOutlet weak var teamView: UIViewX!
    @IBOutlet weak var galleryView: UIViewX!

    @IBOutlet weak var fxScreenView: UIVisualEffectView!
    
    @IBAction func menuButton(_ sender: FloatingActionButton) {
        buttonPress()
    }
    @IBAction func signInButton(_ sender: Any) {
//        if FIRAuth.auth()?.currentUser?.uid == nil{
//            print("SignedINMYFRIEND")
//        }else{
//            print("NOTSIGNEDIN")
//        }
    }
    /////Ratings STUFF
    
//    @IBOutlet weak var ratingsView: UIView!
//    @IBOutlet weak var starsRatingView: CosmosView!
//
//    @IBAction func confirmButtonOfRating(_ sender: Any) {
//
//       // uploadStarsValueOnFirebase();
//    }
//
//    @IBAction func cancelButtonOfRating(_ sender: Any) {
//        ratingsView.isHidden = true;
//
//    }
//    @IBAction func RatingButton(_ sender: Any) {
//        ratingsView.isHidden = false;
//        FIRRemoteConfig.remoteConfig().fetch(withExpirationDuration: 0){ [unowned self](status , error) in
//            guard error == nil else{
//                print(error!)
//                return
//            }
//            print("CHANGED THE Heading")
//            FIRRemoteConfig.remoteConfig().activateFetched();
//            self.updateTheValuesOfStars();
//        }
//
//    }
    
    ////////
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var pageViewTop: UIPageControl!
    
    @IBOutlet weak var iCarosuelView: iCarousel!
  
    @IBOutlet weak var pageViewUnderRedBox: UIPageControl!
   
    @IBAction func JoinUsFormButton(_ sender: Any) {
          UIApplication.shared.open(URL(string: "https://docs.google.com/forms/d/e/1FAIpQLSdWNHCsxHiO3XARHkD0ELOIjcXsNIIBmEK167eLlzASkOl5sQ/viewform?")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func button(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.instagram.com/cess.gndu/?hl=en")! , options:[:], completionHandler: nil)
    }
    @IBAction func buttonFacebook(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/gnducess/")! , options:[:], completionHandler: nil)
    }
    @IBAction func buttonTwitter(_ sender: Any) {
        UIApplication.shared.open(URL(string: "http://www.twitter.com")! , options:[:], completionHandler: nil)
    }
    
    var timer = Timer()
    var counter = 0
    
    
    
    //////URLS OF IMAGES
    
    var url1 = URL(string : "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/Hackathon.png?alt=media&token=52b952d6-c025-42f2-9f40-46dce0b51aba")
    
    var url2 = URL(string : "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/Hackathon.png?alt=media&token=52b952d6-c025-42f2-9f40-46dce0b51aba")
    
    var url3 = URL(string : "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/Register.png?alt=media&token=7a3846b5-b253-48f3-b97c-3446b2d6293e")
    
    var url4 = URL(string : "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/OXO.png?alt=media&token=6dba4d6e-6af1-4f2b-b1f6-761681d04034")
    ////////
    
    var imgArr =   [UIImage(named:"CSOC"),
                    UIImage(named:"Hackathon") ,
                    UIImage(named:"Register") ,
                    UIImage(named:"OXO")]
    
    var myArr =  [UIImage(named:"Unity"),
                  UIImage(named:"Achieve") ,
                  UIImage(named:"Intel") ,
                  UIImage(named:"Member")]
   
//    func updateTheValuesOfStars(){
//        let fetchtedStars = FIRRemoteConfig.remoteConfig().configValue(forKey: "ratingStarValue").numberValue?.doubleValue ?? 3
//        starsRatingView.rating = fetchtedStars;
//
//    }
//
//    func uploadStarsValueOnFirebase(){
//        var starsCount:Double = 3
//        let fetchedStars = FIRRemoteConfig.remoteConfig().configValue(forKey: "ratingStarValue").numberValue ?? 3
//
//        starsCount = Double(fetchedStars)
//    }
//
  
    override func viewDidLoad() {
       
        super.viewDidLoad()
        ////PopUpStuff
        //  PopUpHeadingLabel.text = PopUpHeadingLabelText;
     
        /////SwipeGestureOfPopUpText
        
        
        
        let FirstswipeGestureUp =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleFirstSwipeGestureUp));
        FirstswipeGestureUp.direction = UISwipeGestureRecognizer.Direction.up;
        
        let SecondswipeGestureUp =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleSecondSwipeGestureUp));
        SecondswipeGestureUp.direction = UISwipeGestureRecognizer.Direction.up;
        
        let ThirdswipeGestureUp =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleThirdSwipeGestureUp));
        ThirdswipeGestureUp.direction = UISwipeGestureRecognizer.Direction.up;
        
        let FourthswipeGestureUp =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleFourthSwipeGestureUp));
        FourthswipeGestureUp.direction = UISwipeGestureRecognizer.Direction.up;
        
        PopUpViewForFirstImage.addGestureRecognizer(FirstswipeGestureUp)
        PopUpSecondView.addGestureRecognizer(SecondswipeGestureUp)
        PopUpThirdView.addGestureRecognizer(ThirdswipeGestureUp)
        PopUpFourthView.addGestureRecognizer(FourthswipeGestureUp)
        
        
       ////////////////////DownwardSwipes///////////////////////
        
        let FirstswipeGestureDown =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleFirstSwipeGestureDown));
        FirstswipeGestureDown.direction = UISwipeGestureRecognizer.Direction.down;
  
        
        let SecondswipeGestureDown =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleSecondSwipeGestureDown));
        SecondswipeGestureDown.direction = UISwipeGestureRecognizer.Direction.down;
        
        let ThirdswipeGestureDown =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleThirdSwipeGestureDown));
        ThirdswipeGestureDown.direction = UISwipeGestureRecognizer.Direction.down;
        
        let FourthswipeGestureDown =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleFourthSwipeGestureDown));
        FourthswipeGestureDown.direction = UISwipeGestureRecognizer.Direction.down;
        
        
        PopUpViewForFirstImage.addGestureRecognizer(FirstswipeGestureDown)
        PopUpSecondView.addGestureRecognizer(SecondswipeGestureDown)
        PopUpThirdView.addGestureRecognizer(ThirdswipeGestureDown)
        PopUpFourthView.addGestureRecognizer(FourthswipeGestureDown)
        
        
  ////////////////////////////////////////////////
        
        
        ////////PopUpStuffFinished
        
        
        
//        KingfisherManager.shared.retrieveImage(with: url1! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
//            self.imgArr[0] = image!
//        }
//
//
//        KingfisherManager.shared.retrieveImage(with: url2! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
//            self.imgArr[1] = image!
//        }
//
//        KingfisherManager.shared.retrieveImage(with: url3! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
//            self.imgArr[2] = image!
//        }
//
//        KingfisherManager.shared.retrieveImage(with: url4! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
//            self.imgArr[3] = image!
//        }
      
        ////REMOTECONFIG
        let defaultValuesOfURL = ["url1" : url1 , "url2" : url2 , "url3" : url3 , "url4" : url4]
        FIRRemoteConfig.remoteConfig().setDefaults((defaultValuesOfURL as! [String : NSObject]))

        let defaultValuesOfText = ["popUpMainHeading" : PopUpHeadingLabel.text! , "popUpBodyHeading" : PopUpBodyText.text! ,"popUpSecondViewHeadingText" : PopUpSecondHeadLabel.text! , "popUpSecondViewBodyText" : PopUpSecondBodyText.text! , "popUpThirdViewHeadingText" : PopUpThirdHeadLabel.text! , "popUpThirdViewBodyText" : PopUpThirdBodyText.text! , "popUpFourthViewHeadingText" : PopUpFourthHeadLabel.text! , "popUpFourthViewBodyText" : PopUpFourthBodyText.text! , "popUpFirstVenue" : PopUpFirstVenue.text! , "popUpFirstTiming" : PopUpFirstTiming.text! , "popUpSecondVenue" : PopUpSecondVenue.text!, "popUpSecondTiming" : PopUpSecondTiming.text! , "popUpThirdVenue" : PopUpThirdVenue.text! , "popUpThirdTiming" : PopUpThirdTiming.text! , "popUpFourthVenue" : PopUpFourthVenue.text!, "popUpFourthTiming" : PopUpFourthTiming.text!] as [String : Any]
         FIRRemoteConfig.remoteConfig().setDefaults((defaultValuesOfText as! [String : NSObject]))
        
        /////CHANGING DATA
        

        updateTheValuesOfImages();
        
        /////FECTCHING DATA FROM CLOUD
        let debugSettings = FIRRemoteConfigSettings(developerModeEnabled: true)
        FIRRemoteConfig.remoteConfig().configSettings = debugSettings!
        //////FIX ME DONT USE 0 Seconds for expirationData
        FIRRemoteConfig.remoteConfig().fetch(withExpirationDuration: 0){[unowned self](status , error) in
            guard error == nil else{
                print(error!)
                return
            }
            print("CHANGED THE VALUES")
            FIRRemoteConfig.remoteConfig().activateFetched();
            self.updateTheValuesOfImages();
        }

                KingfisherManager.shared.retrieveImage(with: url1! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
                    self.imgArr[0] = image!
                }
        
        
                KingfisherManager.shared.retrieveImage(with: url2! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
                    self.imgArr[1] = image!
                }
        
                KingfisherManager.shared.retrieveImage(with: url3! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
                    self.imgArr[2] = image!
                }
        
                KingfisherManager.shared.retrieveImage(with: url4! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
                    self.imgArr[3] = image!
                }
     
       
        //////FIX ME DONT USE 0 Seconds for expirationData

        FIRRemoteConfig.remoteConfig().fetch(withExpirationDuration: 0){ [unowned self](status , error) in
            guard error == nil else{
                print(error!)
                return
            }
            print("CHANGED THE Heading")
            FIRRemoteConfig.remoteConfig().activateFetched();
            self.updateTheValuesOfFirstPopUp();
            self.updateTheValuesOfSecondPopUp();
            self.updateTheValuesOfThirdPopUp();
            self.updateTheValuesOfFourthPopUp();
        }
  
        
    ///////ROLLING MENU
        

        menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)


        
     //////CAROSUEL VIEW
        
        
        
        
        pageViewTop.numberOfPages = imgArr.count
        iCarosuelView.type = .rotary
        iCarosuelView.contentMode = .scaleAspectFit
        iCarosuelView.isPagingEnabled = true
        iCarosuelView.isUserInteractionEnabled = true;
        
        pageViewUnderRedBox.numberOfPages = myArr.count
     
        pageViewUnderRedBox.currentPage = 0
        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(self.changeImage), userInfo: nil, repeats: true)
        }
        // Do any additional setup after loading the view.
    }
    
    func updateTheValuesOfImages(){
        ///////Problem is in this line when fectdhec first time gets nil
        let fecthedUrl1 = FIRRemoteConfig.remoteConfig().configValue(forKey: "url1").stringValue ?? "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/Register.png?alt=media&token=7a3846b5-b253-48f3-b97c-3446b2d6293e"
        var test = URL(string: "sadasda")
        url1 = URL(string: fecthedUrl1)
        test = url1
        
        let fecthedUrl2 = FIRRemoteConfig.remoteConfig().configValue(forKey: "url2").stringValue ?? "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/Register.png?alt=media&token=7a3846b5-b253-48f3-b97c-3446b2d6293e"
        url2 = URL(string: fecthedUrl2)
        
        let fecthedUrl3 = FIRRemoteConfig.remoteConfig().configValue(forKey: "url3").stringValue ?? "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/Register.png?alt=media&token=7a3846b5-b253-48f3-b97c-3446b2d6293e"
        url3 = URL(string: fecthedUrl3)
        
        let fecthedUrl4 = FIRRemoteConfig.remoteConfig().configValue(forKey: "url4").stringValue ?? "https://firebasestorage.googleapis.com/v0/b/project-cess-1560581175704.appspot.com/o/Register.png?alt=media&token=7a3846b5-b253-48f3-b97c-3446b2d6293e"
        url4 = URL(string: fecthedUrl4)
        
        
    }
    
    func Alert (Message: String){
        
        let alert = UIAlertController(title: "Bad Connection", message: Message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    @objc func handleFirstSwipeGestureUp(){
        print("HELLOSWIPEUp");
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {

            self.PopUpViewFirstImage.constant = 0
            self.view.layoutIfNeeded()


        }, completion: nil)
        

        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
        self.PopUpViewForFirstImage.isHidden = false;
      
    }
    
    @objc func handleSecondSwipeGestureUp(){
        print("HELLOSWIPEUp");
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.PopUpSecondViewConstrain.constant = 0
            self.view.layoutIfNeeded()
            
            
        }, completion: nil)
        
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
        self.PopUpSecondView.isHidden = false;
    }
    
        @objc func handleThirdSwipeGestureUp(){
            print("HELLOSWIPEUp");
            UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
                self.BlurredImagesPanelConstrain.constant = -500
                self.view.layoutIfNeeded()
                
                print("WorkignAgain");
            }, completion: nil)
            
            
            UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
                
                self.PopUpThirdViewConstrain.constant = 0
                self.view.layoutIfNeeded()
                
                
            }, completion: nil)
    
            
            self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
            self.PopUpThirdView.isHidden = false;
        }
    
    
    
            @objc func handleFourthSwipeGestureUp(){
                print("HELLOSWIPEUp");
                UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
                    self.BlurredImagesPanelConstrain.constant = -500
                    self.view.layoutIfNeeded()
                    
                    print("WorkignAgain");
                }, completion: nil)
                
                
                UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
                    
                    self.PopUpFourthViewConstrain.constant = 0
                    self.view.layoutIfNeeded()
                    
                    
                }, completion: nil)
    
                
                
                self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
                self.PopUpFourthView.isHidden = false;
        }
    

    @objc func handleFirstSwipeGestureDown(){
        print("HELLOSWIPEDown");
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {

            self.PopUpViewFirstImage.constant = 1500
            self.view.layoutIfNeeded()


        }, completion: nil)
        
       
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
//        self.PopUpViewForFirstImage.isHidden = true;
    }
    
    @objc func handleSecondSwipeGestureDown(){
        print("HELLOSWIPEDown");
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.PopUpSecondViewConstrain.constant = 1500
            self.view.layoutIfNeeded()
            
            
        }, completion: nil)
        
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
    }
    
    @objc func handleThirdSwipeGestureDown(){
        print("HELLOSWIPEDown");
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.PopUpThirdViewConstrain.constant = 1500
            self.view.layoutIfNeeded()
            
            
        }, completion: nil)
        
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
    }
  
    @objc func handleFourthSwipeGestureDown(){
        print("HELLOSWIPEDown");
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.BlurredImagesPanelConstrain.constant = -500
            self.view.layoutIfNeeded()
            
            print("WorkignAgain");
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.PopUpFourthViewConstrain.constant = 1500
            self.view.layoutIfNeeded()
            
            
        }, completion: nil)
        
        
        self.BlurredViewandImagesWhenPopUpShows.isHidden = true;
    }
    
 
    @objc func changeImage() {
        
        if counter < myArr.count {
            let index = IndexPath.init(item: counter, section: 0)
            self.collectionView.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
            pageViewUnderRedBox.currentPage = counter
            counter += 1
        } else {
            counter = 0
            let index = IndexPath.init(item: counter, section: 0)
            self.collectionView.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
            pageViewUnderRedBox.currentPage = counter
            counter = 1
        }
}
    
    
    /////ROLLING MENU
    
    func buttonPress() {
      fxScreenView.isHidden = true
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.menuView.transform == .identity {
                self.menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
                self.fxScreenView.isHidden = true
            }
            else {
                self.menuView.transform = .identity
                self.fxScreenView.isHidden = false
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.galleryView.transform == .identity {
                self.galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.galleryView.transform = .identity
              
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.teamView.transform == .identity {
                self.teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.teamView.transform = .identity
            }
        })
    }
    
    
//
/////////COLLECTION VIEW OF MAIN SCREEN
//    
    
}
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return myArr.count
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CCC", for: indexPath) as? DataCollectionViewCell
          
                cell?.img.image = myArr[indexPath.row]
  
            return cell!
        }
    }
    
extension ViewController: UICollectionViewDelegateFlowLayout {
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
            return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let size = collectionView.frame.size
            return CGSize(width: size.width, height: size.height)
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return 0.0
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return 0.0
        }
}


extension ViewController: iCarouselDelegate, iCarouselDataSource {
    func numberOfItems(in carousel: iCarousel) -> Int {
        return imgArr.count
    }
    
    func carousel(_ carousel: iCarousel, viewForItemAt index: Int, reusing view: UIView?) -> UIView {
        var imageView: UIImageView!
      
        if view == nil {
            imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width - 30, height: 280))
            imageView.contentMode = .scaleAspectFill
           

        } else {
            imageView = view as? UIImageView
            
        }
       
        view?.isUserInteractionEnabled = true;
        
        

        imageView.image = imgArr[index]
    
        if imageView.image == imgArr[0] {
            
            
            imageView.isUserInteractionEnabled = true
            let UITapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tappedImage))
            UITapGesture.delegate = self
            imageView.addGestureRecognizer(UITapGesture)
            
            
        }else if imageView.image == imgArr[1]{
            
            
            imageView.isUserInteractionEnabled = true
            let UITapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tappedImage2))
            UITapGesture.delegate = self
            imageView.addGestureRecognizer(UITapGesture)
            
        }else if imageView.image == imgArr[2]{
            
            imageView.isUserInteractionEnabled = true
            let UITapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tappedImage3))
            UITapGesture.delegate = self
            imageView.addGestureRecognizer(UITapGesture)
            
            
        }else if imageView.image == imgArr[3]{
            
            
            imageView.isUserInteractionEnabled = true
            let UITapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tappedImage4))
            UITapGesture.delegate = self
            imageView.addGestureRecognizer(UITapGesture)
            
        }
//        imageView.isUserInteractionEnabled = true
//        let UITapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tappedImage))
//        UITapGesture.delegate = self
//        imageView.addGestureRecognizer(UITapGesture)
        
        pageViewTop.currentPage = carousel.currentItemIndex
        return imageView

    }
    
    
    @objc func tappedImage(){
        
        let debugSettings = FIRRemoteConfigSettings(developerModeEnabled: true)
        FIRRemoteConfig.remoteConfig().configSettings = debugSettings!
        //////FIX ME DONT USE 0 Seconds for expirationData
        FIRRemoteConfig.remoteConfig().fetch(withExpirationDuration: 0){ [unowned self](status , error) in
            guard error == nil else{
                print(error!)
                return
            }
            print("CHANGED THE Heading")
            FIRRemoteConfig.remoteConfig().activateFetched();
            self.updateTheValuesOfFirstPopUp();
        }
        
        KingfisherManager.shared.retrieveImage(with: url1! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
            self.PopUpMainImage.image = image
        }
        
        
        
      //  CustomViewWithinPopUpView.isUserInteractionEnabled = false;
        
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.BlurredViewandImagesWhenPopUpShows.isHidden = false
            self.BlurredImagesPanelConstrain.constant = -165
            self.view.layoutIfNeeded()
            
        }, completion: nil)
        
        PopUpViewForFirstImage.isHidden = false;
       
       UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
        self.PopUpViewFirstImage.constant = 320
        self.view.layoutIfNeeded()
       }, completion: nil)
    }
   
    func updateTheValuesOfFirstPopUp(){
        let fetchtedHeadingText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpMainHeading").stringValue ?? ""
        PopUpHeadingLabel.text = fetchtedHeadingText;
        
        let fetchtedBodyText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpBodyHeading").stringValue ?? ""
        PopUpBodyText.text = fetchtedBodyText;
        
        let fetchedVenueText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpFirstVenue").stringValue ?? ""
        PopUpFirstVenue.text = fetchedVenueText;
    
        let fetchedTimingText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpFirstTiming").stringValue ?? ""
        PopUpFirstTiming.text = fetchedTimingText;
    
    }
    
    
    
    @objc func tappedImage2(){
        print("HELLOWORLD2")
        let debugSettings = FIRRemoteConfigSettings(developerModeEnabled: true)
        FIRRemoteConfig.remoteConfig().configSettings = debugSettings!
        //////FIX ME DONT USE 0 Seconds for expirationData
        FIRRemoteConfig.remoteConfig().fetch(withExpirationDuration: 0){ [unowned self](status , error) in
            guard error == nil else{
                print(error!)
                return
            }
            print("CHANGED THE Heading2")
            FIRRemoteConfig.remoteConfig().activateFetched();
            self.updateTheValuesOfSecondPopUp();
        }
        
        KingfisherManager.shared.retrieveImage(with: url2! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
            self.PopUpMainImage.image = image
        }
        
        
        
      //  PopUpSecondViewCustomView.isUserInteractionEnabled = false;
        
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.BlurredViewandImagesWhenPopUpShows.isHidden = false
            self.BlurredImagesPanelConstrain.constant = -165
            self.view.layoutIfNeeded()
            
        }, completion: nil)
        
        PopUpSecondView.isHidden = false;
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.PopUpSecondViewConstrain.constant = 320
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    
    func updateTheValuesOfSecondPopUp(){
        
        let fetchtedHeadingText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpSecondViewHeadingText").stringValue ?? ""
        PopUpSecondHeadLabel.text = fetchtedHeadingText;
        
        let fetchtedBodyText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpSecondViewBodyText").stringValue ?? ""
        PopUpSecondBodyText.text = fetchtedBodyText;
        
        let fetchedVenueText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpSecondVenue").stringValue ?? ""
        PopUpSecondVenue.text = fetchedVenueText;
        
        let fetchedTimingText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpSecondTiming").stringValue ?? ""
        PopUpSecondTiming.text = fetchedTimingText;
        
    }

    
    @objc func tappedImage3(){
         print("HELLOWORLD3")
        let debugSettings = FIRRemoteConfigSettings(developerModeEnabled: true)
        FIRRemoteConfig.remoteConfig().configSettings = debugSettings!
        //////FIX ME DONT USE 0 Seconds for expirationData
        FIRRemoteConfig.remoteConfig().fetch(withExpirationDuration: 0){ [unowned self](status , error) in
            guard error == nil else{
                print(error!)
                return
            }
            print("CHANGED THE Heading")
            FIRRemoteConfig.remoteConfig().activateFetched();
            self.updateTheValuesOfThirdPopUp();
        }
        
        KingfisherManager.shared.retrieveImage(with: url3! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
            self.PopUpMainImage.image = image
        }
        
        
        
    //    PopUpThirdViewCustomView.isUserInteractionEnabled = false;
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.BlurredViewandImagesWhenPopUpShows.isHidden = false
            self.BlurredImagesPanelConstrain.constant = -165
            self.view.layoutIfNeeded()
            
        }, completion: nil)
        
        PopUpThirdView.isHidden = false;
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.PopUpThirdViewConstrain.constant = 320
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        
    }

    
    func updateTheValuesOfThirdPopUp(){
        let fetchtedHeadingText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpThirdViewHeadingText").stringValue ?? ""
        PopUpThirdHeadLabel.text = fetchtedHeadingText;
        
        let fetchtedBodyText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpThirdViewBodyText").stringValue ?? ""
        PopUpThirdBodyText.text = fetchtedBodyText;
        
        let fetchedVenueText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpThirdVenue").stringValue ?? ""
        PopUpThirdVenue.text = fetchedVenueText;
        
        let fetchedTimingText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpThirdTiming").stringValue ?? ""
        PopUpThirdTiming.text = fetchedTimingText;
        
    }
    
    
    
    @objc func tappedImage4(){
         print("HELLOWORLD4")
        let debugSettings = FIRRemoteConfigSettings(developerModeEnabled: true)
        FIRRemoteConfig.remoteConfig().configSettings = debugSettings!
        //////FIX ME DONT USE 0 Seconds for expirationData
        FIRRemoteConfig.remoteConfig().fetch(withExpirationDuration: 0){ [unowned self](status , error) in
            guard error == nil else{
                print(error!)
                return
            }
            print("CHANGED THE Heading")
            FIRRemoteConfig.remoteConfig().activateFetched();
            self.updateTheValuesOfFourthPopUp();
        }
        
        
        KingfisherManager.shared.retrieveImage(with: url4! as Resource, options: nil, progressBlock: nil) {(image , error , cache , imageUrl) in
            self.PopUpMainImage.image = image
        }
        
        
        
       // PopUpFourthViewCustomView.isUserInteractionEnabled = false;
        UIVisualEffectView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            
            self.BlurredViewandImagesWhenPopUpShows.isHidden = false
            self.BlurredImagesPanelConstrain.constant = -165
            self.view.layoutIfNeeded()
            
        }, completion: nil)
        
        PopUpFourthView.isHidden = false;
        
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: {
            self.PopUpFourthViewConstrain.constant = 320
            self.view.layoutIfNeeded()
        }, completion: nil)
        
    }

    
    func updateTheValuesOfFourthPopUp(){
        let fetchtedHeadingText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpFourthViewHeadingText").stringValue ?? ""
        PopUpFourthHeadLabel.text = fetchtedHeadingText;
        
        let fetchtedBodyText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpFourthViewBodyText").stringValue ?? ""
        PopUpFourthBodyText.text = fetchtedBodyText;
        
        let fetchedVenueText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpFourthVenue").stringValue ?? ""
        PopUpFourthVenue.text = fetchedVenueText;
        
        let fetchedTimingText = FIRRemoteConfig.remoteConfig().configValue(forKey: "popUpFourthTiming").stringValue ?? ""
        PopUpFourthTiming.text = fetchedTimingText;
        
    }
    
    
    @objc func buttonNextAction(sender: UIButton){
        
        print("Next ===== \(sender.tag)")
        switch sender.tag {
        case 0:
            UIApplication.shared.open(URL(string: "https://www.instagram.com/cess.gndu/?hl=en")! , options:[:], completionHandler: nil)
            break
        case 1:
             UIApplication.shared.open(URL(string: "https://www.facebook.com")! , options:[:], completionHandler: nil)
            break
        case 2:
             UIApplication.shared.open(URL(string: "https://www.google.com")! , options:[:], completionHandler: nil)
            break
        case 3:
            UIApplication.shared.open(URL(string: "https://www.twitter.com")! , options:[:], completionHandler: nil)
            break
        default:
            break
        }
    }
}


