//
//  AuthentificationViewController.swift
//  ProjectCess
//
//  Created by Admin on 15/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit
import GoogleSignIn
import Google
import Firebase
import FirebaseCore
import FirebaseAuth
import FirebaseDatabase

class AuthentificationViewController: UIViewController , GIDSignInUIDelegate , GIDSignInDelegate , UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    
  
    
    @IBOutlet weak var labelTest: UILabel!
    @IBOutlet weak var fxScreenView: UIVisualEffectView!
    @IBOutlet weak var galleryView: UIViewX!
    @IBOutlet weak var teamView: UIViewX!
    @IBOutlet weak var menuView: UIViewX!
    
    @IBAction func menuButton(_ sender: FloatingActionButton) {
         buttonPress()
    }
    
    /////ROLLINGMENU
//    @IBOutlet weak var menuView: UIViewX!
//    @IBOutlet weak var teamView: UIViewX!
//    @IBOutlet weak var galleryView: UIViewX!
//
//    @IBAction func menuButton(_ sender: FloatingActionButton) {
//        buttonPress()
//    }
    
    
    //////
    var text:String = ""
    
//    @IBOutlet weak var pickImage: UIImageView!
    
    @IBOutlet weak var idName: UILabel!
    
  
    
    var str:String = ""
//    @IBAction func pickImageButton(_ sender: Any) {
//        let myPickerController = UIImagePickerController()
//        myPickerController.delegate = self
//        myPickerController.allowsEditing = true
//        myPickerController.sourceType = .photoLibrary
//
//
//        self.present(myPickerController, animated: true, completion: nil)
//
//    }
//
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//
//        var selectedImageFromPicker: UIImage?
//        if let editedImage = info[.editedImage] as? UIImage {
//            selectedImageFromPicker = editedImage
//        } else if let originalImage = info[.originalImage] as? UIImage {
//            selectedImageFromPicker = originalImage
//        }
//
//        if let selectedImage = selectedImageFromPicker {
//            pickImage.image = selectedImage
//            ImageUploadFunc();
//        }
//
////        pickImage.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
//        let maskOfImage = UIImageView();
//        maskOfImage.image = UIImage(named: "mask")
//        pickImage.mask = maskOfImage;
//        maskOfImage.frame = pickImage.bounds
//        self.dismiss(animated: true, completion: nil)
//
//    }
//
//
//    func ImageUploadFunc(){
//
//        let imageName = NSUUID().uuidString
//
//        guard let uploadData = pickImage.image!.pngData() else { return };
//        let storageRef = FIRStorage.storage().reference().child("ProfileImages").child(imageName);
//        storageRef.put(uploadData , metadata: nil, completion:{(metaData,error) in
//            if error != nil{
//                print(error!)
//                return
//            }
//            print(metaData!)
//            let uid = FIRAuth.auth()?.currentUser?.uid
//            print(uid!)
//
//            let profileImageUrl = metaData?.downloadURL()?.absoluteString
//
//            let value = ["ProfileImage": profileImageUrl]
//            FIRDatabase.database().reference().child("users").child(uid!).updateChildValues(value)
//        })
//    }
//
//    @IBAction func logOutButton(_ sender: Any) {
//
//        GIDSignIn.sharedInstance()?.signOut()
//
//
//        let storyBoard = UIStoryboard(name: "Main" , bundle: nil)
//        let nextController = storyBoard.instantiateViewController(withIdentifier: "SignInButtonScreen") as! AuthentificationViewController
//        self.present(nextController, animated: true, completion: nil)
//
//    }
//
   
//      let signInButton = GIDSignInButton(frame: CGRect.init(x: 0, y: 0, width: 100, height: 50))

    @IBAction func signInButtonCustom(_ sender: Any) {
      
        if CheckInternet.Connection(){
            GIDSignIn.sharedInstance().clientID = "884776621075-7ku1m12qlj2nhg851kg93kt5u3rl3lof.apps.googleusercontent.com"
            GIDSignIn.sharedInstance()?.uiDelegate = self
            GIDSignIn.sharedInstance()?.delegate = self
            
            GIDSignIn.sharedInstance()?.signIn()
        }
        else{
            self.Alert(Message: "No Internet!! Might be Aliens again")
        }
    }
    
    func Alert (Message: String){
        
        let alert = UIAlertController(title: "Alert", message: Message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ///////ROLLING MENU
//
        menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
//
//
//
        
       // let ref = FIRDatabase.database().referenceFromURL()
        
        
        var error: NSError?
        
        GGLContext.sharedInstance().configureWithError(&error)
        
        if error != nil {
            print(error!)
            return
        }
      
//        GIDSignIn.sharedInstance().clientID = "884776621075-7ku1m12qlj2nhg851kg93kt5u3rl3lof.apps.googleusercontent.com"
//        GIDSignIn.sharedInstance()?.uiDelegate = self
//        GIDSignIn.sharedInstance()?.delegate = self
   
//         signInButtonCustom = view.center
        
//        view.addSubview(signInButton)
       
        // Do any additional setup after loading the view.
    }
    
//    func checkIfUserhasLoggedIn(){
//        if FIRAuth.auth()?.currentUser?.uid != nil {
//            print("SIGNED");
//            PhotoController();
//        }else{
//            print("NOTSIGNED");
//        }
//    }
//
//
    
    
    
    /////ROLLING MENU
    
    func buttonPress() {
        fxScreenView.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            if self.menuView.transform == .identity {
                self.menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
                self.fxScreenView.isHidden = true
            }
            else {
                self.menuView.transform = .identity
                self.fxScreenView.isHidden = false
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.galleryView.transform == .identity {
                self.galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.galleryView.transform = .identity
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.teamView.transform == .identity {
                self.teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.teamView.transform = .identity
            }
        })
    }
    
    
    
    
    
    ///GOOGLE SIGN IN
    
    
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
//        let password:String = ""
//        FIRAuth.auth()?.createUser(withEmail: user.profile.email , password: password, completion:{
//            (user:FIRUser? , error) in
//
      
        if error != nil {
            print(error!)
            
            return
        }else{
           
//                            str = "\(user.profile.email)"
//                            print(str)
//                            idName.text = str
          
            
            ///////WORKING
//            let ref = FIRDatabase.database().reference(fromURL: "https://project-cess-1560581175704.firebaseio.com/")
//            ref.updateChildValues(["UserEmail" : user?.profile.email! , "UserName" : user?.profile.givenName!])
//
            ///////WORKING
            guard let authentication = user.authentication else { return };
            let credential = FIRGoogleAuthProvider.credential(withIDToken: authentication.idToken, accessToken: authentication.accessToken);
            FIRAuth.auth()?.signIn(with: credential) { (result, error) in
               
                if let error = error {
                    print("Failed to sign in and retrieve data with error:", error)
                    return
                }
                
                guard let uid = result?.uid else { return }
                guard let email = result?.email else { return }
                guard let username = result?.displayName else { return }
                
                let values = ["email": email, "username": username]
                
                FIRDatabase.database().reference().child("users").child(uid).updateChildValues(values, withCompletionBlock: { (error, ref) in
                   
                    print("IDSSIDSS")
                })
            }
            
            PhotoController();
            print("This is working");
       
            menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
    
    func PhotoController(){
        let storyBoard = UIStoryboard(name: "Main" , bundle: nil);
        let nextController = storyBoard.instantiateViewController(withIdentifier: "PictureScreen") as! LoggedInScreenViewController;
        self.present(nextController, animated: true, completion: nil);
    }
}
