//
//  TeamViewController.swift
//  ProjectCess
//
//  Created by Admin on 24/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class TeamViewController: UIViewController {
    @IBOutlet weak var menuView: UIViewX!
    @IBOutlet weak var teamView: UIViewX!
    @IBOutlet weak var galleryView: UIViewX!
    @IBAction func menuButton(_ sender: FloatingActionButton) {
        buttonPress()
    }
    @IBOutlet weak var fxScreenView: UIVisualEffectView!
    override func viewDidLoad() {
        super.viewDidLoad()
        menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)

        // Do any additional setup after loading the view.
    }
    
    func buttonPress() {
        fxScreenView.isHidden = true
        UIView.animate(withDuration: 0.3, animations: {
            if self.menuView.transform == .identity {
                self.menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
                self.fxScreenView.isHidden = true
            }
            else {
                self.menuView.transform = .identity
                self.fxScreenView.isHidden = false
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.galleryView.transform == .identity {
                self.galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.galleryView.transform = .identity
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.teamView.transform == .identity {
                self.teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.teamView.transform = .identity
            }
        })
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
