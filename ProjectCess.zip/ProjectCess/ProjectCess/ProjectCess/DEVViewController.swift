//
//  DEVViewController.swift
//  ProjectCess
//
//  Created by Admin on 24/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class DEVViewController: UIViewController {
    
    @IBOutlet weak var view4: UIView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view2: UIView!
    
    @IBOutlet weak var view1: UIView!
    
    
    @IBAction func shubhamFacebook(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func shubhamInsta(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.instagram.com/shubham_kashyap_skp/?hl=en")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func AasthaFacebookId(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/aastha.mehndiratta.79")! , options:[:], completionHandler: nil)
    }
   
    @IBAction func AasthaInstaId(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.instagram.com/aastha_2609/")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func NachiketaFacebookId(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://m.facebook.com/nachiketa.sharma.12?ref=bookmarks")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func NachiketaInstaId(_ sender: Any) {
        UIApplication.shared.open(URL(string: "http://www.instagram.com")! , options:[:], completionHandler: nil)
    }
    
    @IBAction func muskanFacebook(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.facebook.com/muskan.gupta.710667")! , options:[:], completionHandler: nil)
    }
    @IBAction func muskanInsta(_ sender: Any) {
        UIApplication.shared.open(URL(string: "https://www.instagram.com/muskang3583")! , options:[:], completionHandler: nil)
    }
    
    
    
    @IBOutlet weak var menuView: UIViewX!
    @IBOutlet weak var teamView: UIViewX!
    @IBOutlet weak var galleryView: UIViewX!

    @IBAction func menuButton(_ sender: FloatingActionButton) {
        buttonPress()
    }
    
    
    
    
    @IBOutlet weak var fxScreenView: UIVisualEffectView!
    override func viewDidLoad() {
        super.viewDidLoad()
        ///////ROLLING MENU
        
        
        menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        

        // Do any additional setup after loading the view.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        self.view1.alpha = 0
        self.view2.alpha = 0
        self.view3.alpha = 0
        self.view4.alpha = 0
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        view1.center.x -= view.bounds.width
        self.view1.alpha = 1
        UIView.animate(withDuration: 1, delay: 0.5, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options:[], animations: {
            self.view1.center.x += self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        view2.center.x -= view.bounds.width
        self.view2.alpha = 1
        UIView.animate(withDuration: 1, delay: 1.5, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options:[] , animations: {
            self.view2.center.x  += self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        
        view3.center.x -= view.bounds.width
        self.view3.alpha = 1
        UIView.animate(withDuration: 1, delay: 2.5, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [], animations: {
            self.view3.center.x  += self.view.bounds.width
            self.view.layoutIfNeeded()
            
        }, completion: nil)
        
        view4.center.x -= view.bounds.width
        self.view4.alpha = 1
        UIView.animate(withDuration: 1, delay: 3.5, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [], animations: {
            
            self.view4.center.x  += self.view.bounds.width
            self.view.layoutIfNeeded()
            
        }, completion: nil)
        
        
    }
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    /////ROLLING MENU
    
    func buttonPress() {
        fxScreenView.isHidden = true
        UIView.animate(withDuration: 0.3, animations: {
            if self.menuView.transform == .identity {
                self.menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
                self.fxScreenView.isHidden = true
            }
            else {
                self.menuView.transform = .identity
                self.fxScreenView.isHidden = false
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.galleryView.transform == .identity {
                self.galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.galleryView.transform = .identity
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.teamView.transform == .identity {
                self.teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.teamView.transform = .identity
            }
        })
    }
    
    
}
