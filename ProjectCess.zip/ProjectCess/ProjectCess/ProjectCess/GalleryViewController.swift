//
//  GalleryViewController.swift
//  ProjectCess
//
//  Created by Admin on 29/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class GalleryViewController: UIViewController, UIScrollViewDelegate , UIGestureRecognizerDelegate {
    
    @IBOutlet weak var menuView: UIViewX!
    @IBOutlet weak var teamView: UIViewX!
    @IBOutlet weak var galleryView: UIViewX!
    @IBAction func menuButton(_ sender: FloatingActionButton) {
        buttonPress()
    }
    @IBOutlet weak var fxScreenView: UIVisualEffectView!
    
    @IBOutlet weak var ImagesPanel: UIView!
    
    
    @IBAction func backButtonOfGallery(_ sender: Any) {
//        ImageViewContraint.constant = 400;
        imageIndex = 0
        svContent.zoomScale = 1;
        ImagesPanel.isHidden = true
        UIView.transition(with: ImagesPanel, duration: 0.2, options: .transitionCrossDissolve, animations: {
            self.view.layoutIfNeeded()
        }, completion: nil)
        
    }
    
    @IBOutlet weak var ImageViewContraint: NSLayoutConstraint!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var svContent: UIScrollView!
    
    let imgArray = ["HackathonImage","GuruNanakDevUniversity","GalleryPIC","FirstYearIntroToCess","CETDEPT","Jashan","GirlsOfCet","Bhangra","JoyfulTime","CESS 2018-2020","PolarisPic-1"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let swipeLeft =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleLeftSwipe));
        
        swipeLeft.direction = UISwipeGestureRecognizer.Direction.left
        swipeLeft.delegate = self;
        ImagesPanel.addGestureRecognizer(swipeLeft)
        
        let swipeRight =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleRightSwipe));
        
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        swipeRight.delegate = self;
        ImagesPanel.addGestureRecognizer(swipeRight)
        // Do any additional setup after loading the view.
        
        
        svContent.delegate = self
        menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView?{
        return img
    }
    
    var imageIndex: Int = 0
    
    @objc func handleLeftSwipe(){
        
        if imageIndex < 10 {
            imageIndex += 1
        }
        img.image = UIImage(named: imgArray[imageIndex]);
    }
    
    
    @objc func handleRightSwipe(){
        if imageIndex > 0 {
            imageIndex -= 1
        }
        img.image = UIImage(named: imgArray[imageIndex]);
        
     
    }

    func buttonPress() {
        fxScreenView.isHidden = true
        UIView.animate(withDuration: 0.3, animations: {
            if self.menuView.transform == .identity {
                self.menuView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
                self.fxScreenView.isHidden = true
            }
            else {
                self.menuView.transform = .identity
                self.fxScreenView.isHidden = false
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.galleryView.transform == .identity {
                self.galleryView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.galleryView.transform = .identity
            }
        })
        
        UIView.animate(withDuration: 0.3, animations: {
            if self.teamView.transform == .identity {
                self.teamView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            }
            else {
                self.teamView.transform = .identity
            }
        })
    }
    
    
    
    
    @IBAction func showPopup(_ sender: UIButton) {
        
        if sender.tag == 1{
            img.image = UIImage(named: imgArray[0])
            animationOfImageView()
            imageIndex = 0
        }
        else if sender.tag == 2{
            img.image = UIImage(named: imgArray[1])
            animationOfImageView()
             imageIndex = 1
        }
        else if sender.tag == 3{
            img.image = UIImage(named: imgArray[2])
            animationOfImageView()
             imageIndex = 2
        }
        else if sender.tag == 4{
            img.image = UIImage(named: imgArray[3])
            animationOfImageView()
             imageIndex = 3
        }
        else if sender.tag == 5{
            img.image = UIImage(named: imgArray[4])
            animationOfImageView()
             imageIndex = 4
        }
        else if sender.tag == 6{
            img.image = UIImage(named: imgArray[5])
            animationOfImageView()
             imageIndex = 5
        }
        else if sender.tag == 7{
            img.image = UIImage(named: imgArray[6])
            animationOfImageView()
             imageIndex = 6
        }
        else if sender.tag == 8{
            img.image = UIImage(named: imgArray[7])
            animationOfImageView()
             imageIndex = 7
        }
        else if sender.tag == 9{
            img.image = UIImage(named: imgArray[8])
            animationOfImageView()
             imageIndex = 8
        }
        else if sender.tag == 10{
            img.image = UIImage(named: imgArray[9])
            animationOfImageView()
             imageIndex = 9
        }
        else if sender.tag == 11{
            img.image = UIImage(named: imgArray[10])
            animationOfImageView()
             imageIndex = 10
        }
        
    }
    
    func animationOfImageView(){
//        ImageViewContraint.constant = 0
         ImagesPanel.isHidden = false
        UIView.transition(with: ImagesPanel, duration: 0.2, options: .transitionCrossDissolve, animations: {
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
}
