//
//  StartScreenViewController.swift
//  ProjectCess
//
//  Created by Admin on 20/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class StartScreenViewController: UIViewController {
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var gradientView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        animateBackgroundImage()
        
        
        label.numberOfLines = 0
        var text = randomQoute()
        self.label.text = text
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        label.center.x = view.center.x
        label.center.x += view.bounds.width
        UIView.animate(withDuration: 0.7, delay: 0, options: [.curveLinear], animations: {
            self.label.center.x += self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0, execute: {
            self.moveToNextScreen()
        })
        // Do any additional setup after loading the view.
    }
    
    func animateBackgroundImage(){
        UIView.animate(withDuration: 5, delay: 0, options: [.autoreverse , .curveLinear , .repeat], animations:{
            let x = -(self.gradientView.frame.width - self.view.frame.width)
            self.gradientView.transform = CGAffineTransform(translationX: x, y: 0)
        }, completion: nil)
    }
    
    func moveToNextScreen(){
        let mainStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        if let viewController = mainStoryboard.instantiateViewController(withIdentifier: "MainScreen") as? UIViewController {
            self.present(viewController, animated: true, completion: nil)
    }
    
    }
    func randomQoute() -> String {
        let arr1 = ["\"Stay Hungry, Stay Foolish\"\n                     ~ Steve Jobs" , "\"Shut Up and get to work\"\n                     ~ Walt Disney" ,"\"Life is not fair; get used to it\"\n                     ~ Bill Gates" , "\"It takes courage to be successful\"\n                     ~ Jason Bond" , "\"Being Great is a choice\"\n                     ~ Elon Musk" ,"\"Don't Be Afraid to Dream Big\"\n                     ~ Denzel Smith" ,"\"Keep Calm and Love CESS\"\n                     ~ SKP" , "\" Strive for progess. Not perfection.\"\n                     ~ Anonymous" , "\"To a Great Mind nothing is little\"\n                     ~ Sherlock Holmes"]
        var randomNumber = Int.random(in: 0 ... 8)
        var text = arr1[randomNumber]
        return text
        
    }
}

