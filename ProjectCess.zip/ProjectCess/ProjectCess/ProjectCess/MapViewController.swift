//
//  MapViewController.swift
//  ProjectCess
//
//  Created by Admin on 19/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import FirebaseCore
import Firebase
import Lottie

class MapViewController: UIViewController {

    @IBOutlet weak var MapAnimationViewOfLottiee: UIView!
    @IBOutlet weak var MapAnimation: AnimationView!
    
    var viewMap: GMSMapView?
   
    @IBOutlet weak var storyBoardView: GMSMapView!
 
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        StartAnimation();
        
        
       // GMSServices.provideAPIKey("AIzaSyCqVMrAhw6l5VqZEfWIq4S4xUx_L_8N0r8")
        
        let camera = GMSCameraPosition.camera(withLatitude: 31.635533, longitude: 74.824495, zoom: 17.0)
        self.storyBoardView.camera = camera
        
        let initialLoc = CLLocationCoordinate2DMake(31.635533,74.824495)
        let marker = GMSMarker(position: initialLoc)
        //marker.position = CLLocationCoordinate2D(latitude: 31.635533, longitude: 74.824495)
        marker.title = "CESS"
        marker.snippet = "GNDU"
        marker.map = storyBoardView
 
//        let camera = GMSCameraPosition.camera(withLatitude: 31.635533, longitude: 74.824495, zoom: 18.0)
//        self.storyBoardView.camera = camera
//        let map = GMSMapView.map(withFrame: CGRect(x: 100, y: 100, width: 200, height: 200) , camera: camera)
//        viewMap?.center = self.view.center
//        viewMap = map;
//        self.view.addSubview(viewMap!)
//         Do any additional setup after loading the view.
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0, execute: {
            self.disableAnimationOfMapAnimationViewOfLottiee();
        })
        
     
    }
    
   func StartAnimation(){
    MapAnimation.animation = Animation.named("1342-location copy")
    MapAnimation.play()
    MapAnimation.loopMode = .loop
    MapAnimation.contentMode = .scaleAspectFit
    }
    
    func disableAnimationOfMapAnimationViewOfLottiee(){
     MapAnimationViewOfLottiee.isHidden = true
       
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
