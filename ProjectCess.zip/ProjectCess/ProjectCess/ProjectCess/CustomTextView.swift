//
//  CustomTextField.swift
//  ProjectCess
//
//  Created by Admin on 11/07/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

@IBDesignable
class CustomTextField: UITextView {
    @IBInspectable var borderColor: UIColor = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1) {
        didSet{
            self.layer.borderColor = borderColor.cgColor
        }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet{
            self.layer.borderWidth = borderWidth
        }
    }
    
  
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
