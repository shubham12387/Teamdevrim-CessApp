//
//  DataCollectionViewCell.swift
//  ProjectCess
//
//  Created by Admin on 20/06/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class DataCollectionViewCell: UICollectionViewCell {
   
    @IBOutlet weak var img: UIImageView!
    
    

}
