//
//  KavishViewController.swift
//  ProjectCess
//
//  Created by Admin on 14/07/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class KavishViewController: UIViewController , UIGestureRecognizerDelegate {
    @IBOutlet weak var kavishView: UIView!
    
        @IBAction func kavishSareenFacebook(_ sender: Any) {
             UIApplication.shared.open(URL(string: "https://www.facebook.com/rumeet.singh.16")! , options:[:], completionHandler: nil)
        }
    
    
        @IBAction func kavishSareenInsta(_ sender: Any) {
             UIApplication.shared.open(URL(string: "https://www.instagram.com/kavishsareen2799/")! , options:[:], completionHandler: nil)
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight =  UISwipeGestureRecognizer(target: self, action: #selector(self.handleRightSwipe));
        
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        swipeRight.delegate = self;
        kavishView.addGestureRecognizer(swipeRight)
        // Do any additional setup after loading the view.
    }
    
    @objc func handleRightSwipe(){
    print("SwipeRight")
        performSegue(withIdentifier: "MoveToAyush", sender: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
