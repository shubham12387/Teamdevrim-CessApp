//
//  ImageViewController.swift
//  ProjectCess
//
//  Created by Admin on 04/07/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit
import FirebaseStorage

class ImageViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = NSURL(string: "gs://project-cess-1560581175704.appspot.com/AYUSH.jpeg")
        
        URLSession.shared.dataTask(with: url! as URL , completionHandler:{(data , response , error) in
            print("ErrorError")
            
            self.imageView?.image = UIImage(data: data!);
        })
    // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
